<?php

/** Author: Martin Kovalski */

namespace App\PublicModule\presenters;

use Nette\Application\AbortException;
use Nette\Application\UI\Presenter;
use Nette\Security\User;
use Nextras\Dbal\Connection;

abstract class BasePresenter extends Presenter
{
    /** @var Connection @inject */
    public $connection;

    /** @var User @inject */
    public $user;

    /**
     * @throws AbortException
     * Redirect according logged user to his module
     */
    public function beforeRender()
    {
        $this->setLayout('public');

        if($this->user->isLoggedIn())
        {
            switch ($this->user->getRoles()[0])
            {
                case 'admin':
                    $this->redirect(':Admin:Homepage:default');

                case 'business':
                    $this->redirect(':Business:Homepage:default');

                case 'accountant':
                    $this->redirect(':Accountant:Homepage:default');
            }
        }
    }
}