<?php

/** Author: Radek Jůzl */

namespace App\BusinessModule\presenters;

use App\forms\LogInFormFactory;
use App\model\ProfileManager;
use App\model\ImageUploader;
use App\repository\UserRepository;
use Exception;
use Nette\Application\AbortException;
use Nette\Application\UI\Form;
use Nette\Security\User;
use Nette\Utils\FileSystem;

final class ProfilePresenter extends BasePresenter
{
    /** @var User*/
    public $user;

    /** @var UserRepository */
    private $userRepository;

    /** @var LogInFormFactory */
    private $logInFormFactory;

    /** @var ProfileManager */
    private $profileManager;

    /** @var ImageUploader */
    private $imageUploader;

    public function __construct(User $user, UserRepository $userRepository, LogInFormFactory $logInFormFactory, ProfileManager $profileManager, ImageUploader $imageUploader)
    {
        parent::__construct();
        $this->user = $user;
        $this->userRepository = $userRepository;
        $this->logInFormFactory = $logInFormFactory;
        $this->profileManager = $profileManager;
        $this->imageUploader = $imageUploader;
    }

    public function actionDefault()
    {

    }

    public function renderDefault()
    {
        $this->template->profile = $this->userRepository->getUserProfile($this->user->getId()); /** Load data for template */
    }

    public function actionEdit()
    {
        $profile = $this->userRepository->getUserProfile($this->user->getId());
        $this->getComponent("editProfileForm")->setDefaults($profile); /** Load data into form */
    }

    protected function createComponentEditProfileForm(): Form
    {
        $form = $this->logInFormFactory->createEditProfileForm();
        $form->onValidate[] = [$this, "editProfileFormValidate"];
        $form->onSuccess[] = [$this, "editProfileFormSucceeded"];
        return $form;
    }

    public function editProfileFormValidate($form, $values)
    {
        $this->profileManager->editProfileFormValidate($form, $values);
        if($this->isAjax())
        {
            $this->redrawControl("editProfileForm");
        }
    }

    /**
     * @throws AbortException
     * The function detects whether the e-mail has changed - sends a verification e-mail and logs out the user
     */
    public function editProfileFormSucceeded($form, $values)
    {
        $new_email = $this->profileManager->editProfileFormSucceeded($form, $values);
        if($new_email)
        {
            $this->session->destroy();
            $this->user->logout();
            $this->flashMessage('Je potřeba ověřit e-mail a následně se s ním přihlásit');
            $this->redirect(':Public:Homepage:default');
        }

        $this->flashMessage("Změna se provedla", "success");
        $this->redirect(":Business:Profile:default");
    }

    public function actionUpload()
    {

    }

    public function renderUpload()
    {
        $this->template->profile = $this->userRepository->getUserProfile($this->user->getId());
    }

    protected function createComponentUploadAvatarForm(): Form
    {
        $form = $this->logInFormFactory->createUploadAvatarForm();
        $form->onSuccess[] = [$this, "uploadAvatarFormSucceeded"];
        return $form;
    }

    /**
     * @throws AbortException
     */
    public function uploadAvatarFormSucceeded($form, $values)
    {
        $error = 0;
        try
        {
            $this->imageUploader->uploadImgFormSucceeded($form,$values, "avatars");
        }
        catch (Exception $e)
        {
            $error = 1;
            $this->flashMessage($e->getMessage(), 'danger');
            if($this->isAjax())
            {
                $this->redrawControl("uploadAvatarForm");
                $this->redrawControl("flashes");
            }
            else
            {
                $this->redirect("this");
            }
        }
        if(!$error)
        {
            $this->flashMessage("Avatar se nahrál", "success");
            $this->redirect(":Business:Profile:default");
        }
    }

    /**
     * @throws AbortException
     * Function that deletes the avatar. It is called via a handle.
     */
    public function handleDeleteAvatar(): void
    {
        $values = ["avatar_path" => null];
        $old_avatar = $this->userRepository->getUserAvatar($this->user->getId());
        if($old_avatar != null)
        {
            $old_avatar = "../".$old_avatar;
            FileSystem::delete($old_avatar);
        }
        $this->userRepository->updateProfile($this->user->getId(), $values);
        $this->flashMessage("Avatar se smazal", "success");
        $this->redirect(":Business:Profile:default");
    }

}
